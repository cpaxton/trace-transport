import pytest
pytest.importorskip('torch')
from dataclasses import replace
import numpy as np
from scripts import reactive_diagnostics as diagnostic
from scripts import reactive_pilot as pilot
from trace_transport.goodput_reactive import GoodputReactiveEnv,sample_case
from trace_transport.joint_session import ACK_ACTIONS


def test_banks_fail_closed_and_development_is_disjoint(monkeypatch):
    assert not set(diagnostic.bank(150000)) & set(pilot.validation_bank())
    monkeypatch.setattr(pilot,'DOMAIN',{'families':['present','missing']})
    monkeypatch.setattr(pilot,'sample_case',lambda seed:(None,None,{'family':'present'}))
    with pytest.raises(ValueError,match='missing'):pilot.validation_bank()
    monkeypatch.setattr(diagnostic,'DOMAIN',{'families':['present','missing']})
    monkeypatch.setattr(diagnostic,'sample_case',lambda seed:(None,None,{'family':'present'}))
    with pytest.raises(ValueError,match='incomplete'):diagnostic.bank(0)


def test_instrumentation_counts_effects_and_preserves_transport():
    cfg,w,_=sample_case(42,production=.5,drain=.2,stage='easy')
    cfg=replace(cfg,initial_rate=2000.,control_interval=.02,bandwidth_bps=1000000.,feedback_bandwidth_bps=1000000.,base_rtt=.01,jitter=0.,loss=0.,ack_loss=0.)
    plain=GoodputReactiveEnv(cfg,w);audit=diagnostic.InstrumentedEnv(cfg,w)
    plain.reset(seed=42);audit.reset(seed=42)
    tx=np.zeros((plain.count,3));slow=np.full(plain.count,ACK_ACTIONS.index((32,.25))+1)
    while plain.now<.2:
        plain.step(tx,slow);audit.step(tx,slow)
        if any(s.pending for s in plain.sessions):break
    assert any(s.pending for s in plain.sessions)
    plain.step(tx,np.ones(plain.count,int));audit.step(tx,np.ones(plain.count,int))
    assert audit.control_stats['changes_with_pending']>0
    assert audit.control_stats['control_flushes']>0
    assert audit.control_stats['control_flush_wire_bytes']>0
    while not plain.done():
        plain.step(tx,slow);audit.step(tx,slow)
    assert plain.metrics()==audit.metrics()


def test_pilot_records_the_exact_shaped_training_configuration(tmp_path,monkeypatch):
    import json,sys
    from dataclasses import asdict
    monkeypatch.chdir(tmp_path)
    (tmp_path/'source-manifest.json').write_text('{}')
    monkeypatch.setattr(sys,'argv',['reactive-pilot','--output',str(tmp_path/'run'),'--decisions','2'])
    class StopBeforeTraining(Exception):pass
    def inspect(output,cfg,model):
        plan=json.loads((tmp_path/'run/plan.json').read_text())
        assert cfg.progress_shaping is True
        assert plan['base_training']==asdict(cfg)
        raise StopBeforeTraining
    monkeypatch.setattr(pilot,'train',inspect)
    with pytest.raises(StopBeforeTraining):pilot.main()


def test_seeded_sampling_audit_is_repeatable_and_applies_non_teacher_actions(tmp_path):
    import torch
    from trace_transport.joint_models import JointModelConfig,SenderActor,ReceiverActor,CentralCritic,save_checkpoint
    torch.set_num_threads(1);torch.manual_seed(9)
    cfg=JointModelConfig(history=2,width=8,layers=1,heads=2)
    baseline=dict(rate='delay-fast',scheduler='edf',feedback='budgeted',initial_rate=512000.,batch=1,delay=0.)
    checkpoint=tmp_path/'actor.pt'
    save_checkpoint(checkpoint,SenderActor(cfg),ReceiverActor(cfg),CentralCritic(),cfg,
        dict(profile='goodput-v6',baseline=baseline,training={}))
    a=diagnostic.action_case(150000,checkpoint,baseline,production=.1,drain=.1,receiver_mode='sampled',sampling_seed=12)
    b=diagnostic.action_case(150000,checkpoint,baseline,production=.1,drain=.1,receiver_mode='sampled',sampling_seed=12)
    assert a==b
    assert sum(a['applied_receiver_choices'].values())==a['active_receiver_decisions']
    assert any(int(k)>0 and v>0 for k,v in a['applied_receiver_choices'].items())
