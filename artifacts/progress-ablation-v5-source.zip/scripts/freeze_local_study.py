"""Freeze source and hard-link installed dependencies for parallel local work.

Only source/test files are bundled. Runtime environments remain outside Git.
Existing dependency files must share the destination filesystem; no large copy
fallback or reinstall is attempted. No existing target is overwritten.
"""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import zipfile
from scripts.caliban_deploy import package


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('destination',type=Path);p.add_argument('--cpu-runtime',action='store_true');args=p.parse_args()
    out=args.destination.resolve();source=Path(sysconfig.get_paths()['purelib'])
    if out.exists():raise ValueError('immutable destination already exists')
    if not args.cpu_runtime and source.stat().st_dev!=out.parent.stat().st_dev:raise ValueError('hard-link freeze requires the same filesystem')
    out.mkdir();package(Path(__file__).resolve().parents[1],out/'source.zip')
    with zipfile.ZipFile(out/'source.zip') as z:z.extractall(out)
    subprocess.run(['uv','venv','--python',str(Path(sys.executable).resolve()),str(out/'.venv')],check=True,
                   env={**os.environ,'UV_CACHE_DIR':'/tmp/trace-uv-cache'})
    target=out/'.venv/lib'/('python'+str(sys.version_info.major)+'.'+str(sys.version_info.minor))/'site-packages'
    if args.cpu_runtime:
        runtime_env={**os.environ,'UV_CACHE_DIR':'/tmp/trace-uv-cache','TMPDIR':str(out)}
        python=out/'.venv/bin/python'
        subprocess.run(['uv','pip','install','--python',str(python),'--no-cache','torch==2.14.1','--index-url','https://download.pytorch.org/whl/cpu'],check=True,env=runtime_env)
        subprocess.run(['uv','pip','install','--python',str(python),'--no-cache','numpy==2.5.4'],check=True,env=runtime_env)
        (target/'trace_transport_frozen.pth').write_text(str(out/'src')+'\n')
        print(out);return
    for entry in source.iterdir():
        if entry.name.endswith('.pth') or entry.name.startswith(('__editable__','trace_transport')):continue
        destination=target/entry.name
        if entry.is_dir():shutil.copytree(entry,destination,copy_function=os.link,symlinks=True,dirs_exist_ok=True)
        elif entry.is_symlink():destination.symlink_to(os.readlink(entry))
        else:os.link(entry,destination)
    (target/'trace_transport_frozen.pth').write_text(str(out/'src')+'\n')
    print(out)


if __name__=='__main__':main()
